create index IX_DE7E9795 on AMF_REGISTRATION_LOG (eventType[$COLUMN_LENGTH:75$], userId);
create index IX_928EB4E3 on AMF_REGISTRATION_LOG (userId);